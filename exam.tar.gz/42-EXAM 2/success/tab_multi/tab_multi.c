#include <unistd.h>

void ft_putchar(char c)
{
    write(1, &c, 1);
}
int ft_atoi(char *str)
{

    int i = 0;
    int num = 0;
    while (str[i])
    {
        num = num * 10 + str[i] - '0';
        i++;
    }
    return num;
}
void ft_putnbr(int i)
{

    if (i <= 9)
    {
        ft_putchar(i + 48);
    }

    else if (i > 9)
    {
        ft_putnbr(i / 10);
        ft_putnbr(i % 10);
    }
}

int main(int argc, char **argv)
{

    if (argc == 2)
    {

        int i = 1;
        int result = 0;
        int j = ft_atoi(argv[1]);
        while (i < 10)
        {
            result = i * j;
            ft_putnbr(i);
            write(1," x ",3);
            ft_putnbr(j);
            write(1," = ",3);
            ft_putnbr(result);
            ++i;
        }
           write(1,"\n",1);
    }
else 
     write(1, "\n", 1);
     return 0;
}