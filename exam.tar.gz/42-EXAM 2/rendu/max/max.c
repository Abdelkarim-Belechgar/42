int		max(int* tab, unsigned int len)
{
	int	z;
	int	large;

	if (len == 1)
		return (rab[0]);
	z = 0;
	large = tab[--len];
	while (len > 0)
	{
		if (tab[len] < tab[len - 1])
			large = tab[len - 1];
		len--;
	}
	return (large);
}
