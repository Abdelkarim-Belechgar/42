#include<unistd.h>
void capital(char *str)
{
	int i = 0;
	while(str[i] == ' ' || str[i] == '\t' )
		i++;
	while(str[i])
	{
		if (str[i] >= 'A' && str[i] <= 'Z' && (str[i] != ' ' || str[i] != '\t'))
			str[i] += 32;
		if(str[0] >= 'a' && str[0] <= 'z')
				str[i] -= 32;
		i++;
	}
	i = 0;
	while(str[i])
	{
			if(str[i] >= 'a' && str[i] <= 'z'  && (str[i - 1] == ' ' || str[i - 1] == '\t'))
				str[i] -= 32;
			write(1,&str[i],1);	
			i++;
	}
	write(1,"\n",1);
}
int main(int ac,char **av)
{
	int i = 1;
	if(ac > 1)
	{
		while(i < ac)
		{
			capital(av[i]);
			i++;
		}
	}
	else
		write(1,"\n",1);
}