#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
int plusmoin(int x)
{
    if(x < 0)
        return(-x);
    else
        return(x);
}
int     *ft_range(int start, int end)
{
    int i = 0;
    int *tab = malloc(plusmoin(sizeof(int)* ( end - start) + 1));
    while(end > start)
    {
        tab[i] = start;
        start++;
        i++;
    } 
    tab[i] = end;
    while(start > end)
    {
        tab[i] = start;
        start--;
        i++;
    }
    tab[i] = end;
    return(tab);
}
// int main()
// {
//     int i = 0;
//     int start  = -1;
//     int end  = 2;
//     int *tab  = ft_range(start , end);
//     while( i <=abss(start - end))
//     {
//         printf("%d\n",tab[i]);
//         i++;
//     }
// }
