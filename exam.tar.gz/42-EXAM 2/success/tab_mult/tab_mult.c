#include <unistd.h>
int ft_atoi(char *str)
{
    int i = 0;
    int num = 0;
    while(str[i] == ' ')
                i++;
    while(str[i]>='0' && str[i]<='9')
    {
                num = num*10 +str[i]-'0';
                i++;
        }
    return num;

}
    void ft_putnbr(int i)
    {
        int num  = 0;
        if(i>9)
            ft_putnbr(i/10);
            num  = num*10+i%10+'0';
            write(1,&num,1);

    }
    #include <stdio.h>
int main(int argc , char **argv)
{
    if(argc  == 2)
    {
        int a  = ft_atoi(argv[1]);
        int result ;
        int i = 1;
        while(i <=9)
        {
            ft_putnbr(i);
            write(1," x ",3);
            ft_putnbr(a);
            write(1," = ",3);
            result  = i*a;
            ft_putnbr(result);
            write(1,"\n",1);
            i++;

        }

    }
    else 
  write(1,"\n",1);
}