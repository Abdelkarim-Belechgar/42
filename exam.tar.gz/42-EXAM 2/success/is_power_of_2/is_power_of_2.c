int	    is_power_of_2(unsigned int n)
{
	unsigned int	z;
	unsigned int	y;

	z = 0;
	y = 0;
	while (y <= n)
	{
		if (y == n)
			return (1);
		z++;
		y = z * z;
	}
	return (0);
}
