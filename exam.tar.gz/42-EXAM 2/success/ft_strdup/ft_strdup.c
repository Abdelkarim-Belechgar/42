#include <unistd.h>
#include <stdlib.h>
int ft_strlen(char *str)
{
    int i = 0;
    while(str[i])
        i++;
    return i;


}
char    *ft_strdup(char *src)
{
    int i = 0;
    char *ptr = malloc(sizeof(char) * ft_strlen(src)+1);
            if(!ptr)
                return NULL;
    while(i<=ft_strlen(src))
    {
        ptr[i] = src[i];
        i++;
    }
    ptr[i] = '\0';
    return ptr;
}