#include <stdio.h>

    int ft_strlen(char *str)
    {
        int i = 0;
        while(str[i])
            i++;
        return i;
    }

char *ft_strrev(char *str)
{
    int i =0 ;
    int len = ft_strlen(str);
    len--;
    int temp = 0;
    while(len>i)
{
    temp = str[i];
    str[i] = str[len];
        str[len] = temp;
        len--;
        i++;
}

        return str;

}

int main()
{
    char str[] = "med charaf bouderraoui";
    char *ptr = ft_strrev(str);
        printf("%s\n", ptr);
 
         
}