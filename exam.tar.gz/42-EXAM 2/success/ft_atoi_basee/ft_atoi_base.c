#include <unistd.h>
int valid(char c , int base)
{
    int i = 0;
    char min[] = "0123456789abcdef";
    char max[] = "0123456789ABCDEF";

        while( i <base)
        {
            if(min[i] == c || max[i] == c)
                    return 1;
                i++;
        }
            return 0;
}



int     ft_atoi_base(const char *str, int str_base)
{
    int i = 0;
    int num = 0;
    int sign = 1;
    while(str[i] == ' ')
        i++;
    if(str[i] == '-')
        {
            sign*=-1;
            i++;
        }
    else if(str[i] == '+')
        i++;
    while(valid(str[i], str_base))
    {
            if(str[i]>='0'&& str[i]<='9')
                num  = num*str_base+str[i]-'0';
            else if(str[i]>='a' && str[i]<='f')
                num = num*str_base +str[i]-'a'+10;
            else if(str[i]>='A' && str[i]<='F')
                num = num*str_base +str[i]-'A' +10;
            i++;
    }
    return sign*num;


}
// #include <stdio.h>
// int main()
// {
//     printf( "%d\n",ft_atoi_base("0",16));

// }
