#include <unistd.h>

int ft_atoi(char *str)
{
    int i = 0;
    int num = 0;
    while(str[i] == ' ')
        i++;
    while(str[i])
    {
        if(str[i]>='0' && str[i]<='9')
            num = num*10 +str[i]-'0';
            i++;
    }
    return num;

}
void ft_puthex(int num)
{
    char hex[] = "0123456789abcdef";
    if(num>=16)
        ft_puthex(num/16);

      
        write(1,&hex[num%16],1);

}

int main(int argc , char **argv)
{
if(argc == 2)
{

int a = ft_atoi(argv[1]);
ft_puthex(a);
}
  write(1,"\n",1);
}