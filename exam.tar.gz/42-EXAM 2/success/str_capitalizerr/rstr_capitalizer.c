#include <unistd.h>
#include <stdlib.h>
    int ft_count(int num)
    {   
        
    }