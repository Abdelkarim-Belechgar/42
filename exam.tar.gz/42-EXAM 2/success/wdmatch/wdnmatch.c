#include <unistd.h>
void ft_putstr(char *str)
{
    int i = 0;
    while(str[i])
    {
        write(1,&str[i],1);
            i++;

    }

}
int ft_strlen(char *str)
{
    int i = 0;
    while(str[i])
        i++;
    return i;

}
#include <stdio.h>
int main(int argc, char **argv)
{
    int i = 0;
    int j = 0;
    int ha = 0;
    while (argv[1][i])
    {
        j = 0;
        while(argv[2][j]){
        if (argv[1][i] == argv[2][j])
        {
            ha++;
          break;
        }
        j++;
        }
        i++;
    }
    if(ha == ft_strlen(argv[1]))
        ft_putstr(argv[1]);

}
