#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
int ft_count(int num)
{
    int i = 0;
    if(num<=0)
        i++;
    while(num)
    {
        num/=10;
        i++;
    }
    return i;
}
    char *ft_itoa(int nbr)
    {
        int i = 0;
        int count  = ft_count(nbr)-1;;
        int count_last =ft_count(nbr);
char *str= malloc(sizeof(char)*count+1);
        long num = nbr;
        if(num<0)
            {
                str[0] = '-';
                    num*=-1;
            }
        if(num  == 0)
                    str[0] = '0';
        while(num)
        {   
            i = num%10;
            str[count] = i+'0';
            num/=10;
            count--;
        }
        str[count_last] = '\0';
        return str;
    }
// int main()
// {
//     printf("%s\n",ft_itoa(-1546));

// }