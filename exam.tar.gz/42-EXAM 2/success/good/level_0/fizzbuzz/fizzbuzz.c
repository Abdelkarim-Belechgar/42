#include <unistd.h>

void	ft_putnbr(int nbr)
{
	char	str[10] = "0123456789";

	if (nbr > 9)
		ft_putnbr(nbr / 10);
	write(1, &str[nbr % 10], 1);
}

int	main(void)
{
	int	z;

	z = 1;
	while (z < 101)
	{
		if (z % 15 == 0)
			write(1, "fizzbuzz", 8);
		else if (z % 3 == 0)
			write(1, "fizz", 4);
		else if (z % 5 == 0)
			write(1, "buzz", 4);
		else
			ft_putnbr(z);
		write (1, "\n", 1);
		z++;
	}
}
