#include <unistd.h>
#include <stdlib.h>

void pgcd(int a , int b)
{
    int i = a;
    while(i>0)
    {
        if(1%i == 0 && b%i == 0)
            {
                printf("%d");
                    return;
            }
            i--;

    }   
    



}
    int main(int argc , char **argv)
{
    if(argc == 3)
    {
            int a = atoi(argv[1]);
            int b = atoi(argv[2]);
    pgcd(a,b);

    }
    write(1,"\n",1);

}