#include <unistd.h>

int	ft_strlen(char *str)
{
	int	z;

	z = 0;
	while (str[z])
		z++;
	if (z > 0)
		z--;
	return (z);
}

int	main(int argc, char *argv[])
{
	int	z;

	if (argc == 2)
	{
		z = ft_strlen(argv[1]);
		if (z > 0)
		{
			while (z >= 0)
			{
				write(1, &argv[1][z], 1);
				z--;
			}
		}
	}
	write(1, "\n", 1);
	return (0);
}
