#include <unistd.h>

int	count_word(char *str)
{
	int	z;
	int	y;

	z = 0;
	y = 0;
	while (str[z])
	{
		while (str[z] && (str[z] == ' ' || str[z] == '\t'))
			z++;
		if (str[z])
			y++;
		while (str[z] && str[z] != ' ' && str[z] != '\t')
			z++;
	}
	return (y);
}

int	main(int argc, char *argv[])
{
	int	z;
	int	y;

	if (argc ==2)
	{
		z = 0;
		y = count_word(argv[1]);
		while  (y >= 1 )
		{
			while (argv[1][z] && (argv[1][z] == ' ' || argv[1][z] == '\t'))
				z++;
			while (argv[1][z] && argv[1][z] != ' ' && argv[1][z] != '\t')
			{
				write(1, &argv[1][z], 1);
				z++;
			}
			y--;
			if (y)
				write(1 , "   ", 3);
		}
	}
	write(1, "\n", 1);
	return (0);
}
