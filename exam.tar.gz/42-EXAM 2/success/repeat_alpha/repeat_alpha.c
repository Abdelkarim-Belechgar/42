#include <unistd.h>

int	main(int argc, char *argv[])
{
	int	z;

	if (argc == 2)
	{
		while (*argv[1])
		{
			if (*argv[1] >= 65 && *argv[1] <= 90)
				z = *argv[1] - 64;
			else if (*argv[1] >= 97 && *argv[1] <= 122)
				z = *argv[1] - 96;
			else
				z = 1;
			while (z--)
				write(1, argv[1], 1);
			argv[1]++;
		}
	}
	write(1, "\n", 1);
	return (0);
}
