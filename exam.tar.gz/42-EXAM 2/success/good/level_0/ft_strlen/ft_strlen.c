int	ft_strlen(char *str)
{
	int	z;

	z = 0;
	while (*str)
	{
		z++;
		str++;
	}
	return (z);
}
