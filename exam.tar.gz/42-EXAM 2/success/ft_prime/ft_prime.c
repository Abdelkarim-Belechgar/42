#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main(int ac , char **av)
{
    int i = 1;
    int number = atoi(av[1]);
    if(ac  == 2)
    {
        if( number == 1)
            return(0);
        while(number > i)
        {
            if(number % i == 0)
            {
                printf("%d",i);
                if(number == i)
                        break;
                printf("*");
                number /= i;
                i = 1;
            }

        }
    }
    write(1,"\n",1);
}