#include <unistd.h>

int	ft_atoi(char *str)
{
	int	z;

	z = 0;
	if (!str || (*str < '0' || *str > '9'))
		return (0);
	while (*str)
	{
		z = z * 10 + *str - 48;
		str++;
	}
	return (z);
}

void	ft_putnbr(int nbr)
{
	char	str[10] = "0123456789";
	if (nbr > 9)
		ft_putnbr(nbr / 10);
	write(1, &str[nbr % 10], 1);
}

int	main(int argc, char *argv[])
{
	(void)argc;
	int	z;
	int	y;

	z = ft_atoi(argv[1]);
	if (z)
		y = 1;
	else
		y = 0;
	while (z && y)
	{
		if ((z % 2) != 0)
			y += z;
		z--;
	}
	ft_putnbr(y);
	write(1, "\n", 1);
	return (0);
}
