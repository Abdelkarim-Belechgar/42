

#include <stdio.h>
unsigned char	reverse_bits(unsigned char octet)
{
    unsigned char result ;
    int i  = 7;
    while(i >=0)
    {
        result = result*2+(octet%2);
        result/=2;
        i--;

    }
    return result

}