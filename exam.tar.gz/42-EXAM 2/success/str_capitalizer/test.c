#include<unistd.h>
#include <stdlib.h>

void ft_puthex(int i)
{
    char min[] = "0123456789abcdef";
    if(i>=16)
        ft_puthex(i/16);
    write(1,&min[i%16],1);

}

#include <stdio.h>
int main(int argc , char **argv)
{
if(argc == 2)
{
    int i = atoi(argv[1]);
    ft_puthex(i);
}
write(1,"\n",1);

}