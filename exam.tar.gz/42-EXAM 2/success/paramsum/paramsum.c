#include <unistd.h>

void ft_putnbr(int i)
{
    int num = 0;
    if(i>9)
    {
        ft_putnbr(i/10);
    }
        num  = num*10+i%10+'0';
        write(1,&num,1);

}

int main(int argc , char **argv)
{
    if(argc>1)
    {
        argc--;
            ft_putnbr(argc);        

    }
    else 
        ft_putnbr(0);
        write(1,"\n",1);
}