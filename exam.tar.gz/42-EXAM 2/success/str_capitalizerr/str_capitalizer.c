#include <unistd.h>

void capita(char *str)
{
    int i = 0;
    while(str[i])
    {
        while(str[i] == ' ' || str[i] == '\t' && str[i])
            {
                write(1,&str[i],1);
                i++;
            }
            if(str[i])
            {
                if(str[i]>='a' && str[i]<='z')
                    str[i]-=32;
                    write(1,&str[i],1);
                                i++;
            }
    while(str[i] && str[i]!=' ' && str[i]!= '\t')

    {
             if(str[i]>='A' && str[i]<='Z')
        str[i]+=32;
        write(1,&str[i],1);
            i++;
    }
    }
        write(1,"\n",1);
}

int main(int argc, char **argv)
{
    int i = 0;
    if (argc > 1)
    {
        
        int i = 1;
        while (i < argc)
        {
            capita(argv[i]);
            i++;
        }
    }
    write(1, "\n", 1);
}