#include <unistd.h>
#include <stdlib.h>

typedef struct	s_list
{
	char			c;
	int				z;
	struct	s_list	*next;
}				t_list;

void	lst_add_back(t_list **head, t_list *new)
{
	t_list	*node;

	if (!*head)
	{
		*head = new;
		return ;
	}
	node = *head;
	while (node->next)
		node = node->next;
	node->next = new;
}

t_list	*lst_new(char c)
{
	t_list	*node;

	node = (t_list*)malloc(sizeof(t_list));
	if (!node)
		return (NULL);
	node->c = c;
	node->z = 0;
	node->next = NULL;
	return (node);
}

int	check_deeplucate(t_list	*head, char c)
{
	while (head)
	{
		if (head->c == c)
			return (1);
		head = head->next;
	}
	return (0);
}

void	ft_check(t_list *head, char c)
{
	while (head)
	{
		if (head->c == c)
			head->z = 1;			
		head = head->next;
	}
}

int	main(int argc, char *argv[])
{
	t_list	*head;
	t_list	*node;
	int		z;

	head = NULL;
	if (argc == 3)
	{
		while (*argv[1])
		{
			z = check_deeplucate(head, *argv[1]);
			if (!z)
				lst_add_back(&head, lst_new(*argv[1]));
			argv[1]++;
		}
		while (*argv[2])
		{
			ft_check(head, *argv[2]);
			argv[2]++;
		}
		node = head;
		while (node)
		{
			if (node->z == 1)
				write(1, &node->c, 1);
			node = node->next;
		}
		free(head);
	}
	write(1, "\n", 1);
	return (0);
}
